<?php
$host = '34.173.247.77';
$user = "root";
$pass = 'jZG|E"9iQZc-TUlv';
$db = "GookPochita";
$conexion = mysqli_connect($host, $user, $pass, $db);
mysqli_set_charset($conexion, "utf8mb4");
?>
